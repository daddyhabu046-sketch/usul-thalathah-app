Usul Thalathah – Hausa & Arabic

Android Studio project. The app bundles the provided Arabic/Hausa interleaved PDF for offline reading and includes page navigation, last-page resume, and a saved bookmark.

To build the APK:
1. Open this folder in Android Studio (recent version).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio will create app/build/outputs/apk/debug/app-debug.apk.

Note: This delivery is the Android Studio source project, not a compiled APK. The current workspace has Java but no Android SDK/Gradle installation, so an APK cannot be compiled here. The PDF included in the app is the interleaved 61-page file prepared from the supplied Hausa and Arabic PDFs.
