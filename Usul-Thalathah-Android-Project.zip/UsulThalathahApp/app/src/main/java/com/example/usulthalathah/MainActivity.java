package com.example.usulthalathah;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private PdfRenderer renderer;
    private ParcelFileDescriptor descriptor;
    private ImageView pageView;
    private TextView pageLabel;
    private SeekBar pageSeek;
    private int page = 0;
    private boolean changingSeek = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(20, 83, 61));
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();
        try {
            File pdf = new File(getFilesDir(), "book.pdf");
            if (!pdf.exists()) {
                try (InputStream in = getAssets().open("book.pdf"); FileOutputStream out = new FileOutputStream(pdf)) {
                    byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                }
            }
            descriptor = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY);
            renderer = new PdfRenderer(descriptor);
            page = Math.max(0, Math.min(getPreferences(0).getInt("last_page", 0), renderer.getPageCount()-1));
            pageSeek.setMax(renderer.getPageCount()-1);
            showPage();
        } catch (Exception e) { Toast.makeText(this, "Could not open the book: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(246,244,237));
        TextView title = new TextView(this); title.setText("Usul Thalathah\nHausa & Arabic"); title.setTextColor(Color.WHITE); title.setTextSize(21); title.setGravity(Gravity.CENTER); title.setPadding(12,16,12,16); title.setBackgroundColor(Color.rgb(20,83,61)); root.addView(title);
        pageView = new ImageView(this); pageView.setAdjustViewBounds(true); pageView.setScaleType(ImageView.ScaleType.FIT_CENTER); pageView.setBackgroundColor(Color.WHITE);
        root.addView(pageView, new LinearLayout.LayoutParams(-1, 0, 1));
        pageLabel = new TextView(this); pageLabel.setGravity(Gravity.CENTER); pageLabel.setTextColor(Color.DKGRAY); pageLabel.setTextSize(15); pageLabel.setPadding(8,5,8,0); root.addView(pageLabel);
        pageSeek = new SeekBar(this); pageSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar s,int p,boolean u){ if(u){page=p; showPage();}} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} }); root.addView(pageSeek);
        LinearLayout controls = new LinearLayout(this); controls.setGravity(Gravity.CENTER); controls.setPadding(6,4,6,12);
        Button prev = button("◀ Previous"); prev.setOnClickListener(v -> { if(page>0){page--;showPage();} }); controls.addView(prev, weight());
        Button mark = button("★ Bookmark"); mark.setOnClickListener(v -> {getPreferences(0).edit().putInt("bookmark",page).apply(); Toast.makeText(this,"Bookmark saved at page "+(page+1),Toast.LENGTH_SHORT).show();}); controls.addView(mark, weight());
        Button saved = button("Go to bookmark"); saved.setOnClickListener(v -> {page=getPreferences(0).getInt("bookmark",0);showPage();}); controls.addView(saved, weight());
        Button next = button("Next ▶"); next.setOnClickListener(v -> {if(renderer!=null && page<renderer.getPageCount()-1){page++;showPage();}}); controls.addView(next, weight());
        root.addView(controls); setContentView(root);
    }
    private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0, dp(48),1);}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private Button button(String text){Button b=new Button(this);b.setText(text);b.setTextSize(10);b.setAllCaps(false);return b;}
    private void showPage(){
        if(renderer==null)return;
        try(PdfRenderer.Page p=renderer.openPage(page)){
            int width=Math.max(600,getResources().getDisplayMetrics().widthPixels*2);
            int height=(int)((float)width*p.getHeight()/p.getWidth());
            Bitmap bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888); bitmap.eraseColor(Color.WHITE);
            p.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); pageView.setImageBitmap(bitmap);
            pageLabel.setText("Page "+(page+1)+" of "+renderer.getPageCount()+"  •  Arabic followed by Hausa");
            changingSeek=true;pageSeek.setProgress(page);changingSeek=false;
            getPreferences(0).edit().putInt("last_page",page).apply();
        }catch(Exception e){Toast.makeText(this,"Page could not be displayed",Toast.LENGTH_SHORT).show();}
    }
    @Override protected void onDestroy(){super.onDestroy();try{if(renderer!=null)renderer.close();if(descriptor!=null)descriptor.close();}catch(Exception ignored){}}
}
